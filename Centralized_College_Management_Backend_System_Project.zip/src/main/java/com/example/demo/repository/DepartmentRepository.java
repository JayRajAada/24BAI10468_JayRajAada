package com.example.demo.repository;

import com.example.demo.model.Department;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import java.util.List;

public interface DepartmentRepository extends MongoRepository<Department, String> {
    
    @Query("{ 'name': { $regex: ?0, $options: 'i' } }")
    List<Department> searchByName(String keyword);
}