package com.example.demo.controller;

import com.example.demo.model.Department;
import com.example.demo.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/departments")
public class DepartmentController {

    @Autowired
    private DepartmentRepository repository;

    // 1. CREATE (POST)
    @PostMapping
    public Department createDepartment(@RequestBody Department department) {
        System.out.println("=========================================");
        System.out.println("Request Method: POST");
        System.out.println("Endpoint: /api/departments");
        System.out.println("Action: Saving new department to MongoDB...");
        System.out.println("Payload Name: " + department.getName());
        System.out.println("Payload Code: " + department.getCode());
        System.out.println("=========================================");
        
        return repository.save(department);
    }

    // 2. READ ALL (GET)
    @GetMapping
    public List<Department> getAllDepartments() {
        System.out.println("=========================================");
        System.out.println("Request Method: GET");
        System.out.println("Endpoint: /api/departments");
        System.out.println("Action: Fetching all departments from database...");
        System.out.println("=========================================");
        
        return repository.findAll();
    }

    // 3. UPDATE (PUT)
    @PutMapping("/{id}")
    public Department updateDepartment(@PathVariable String id, @RequestBody Department department) {
        System.out.println("=========================================");
        System.out.println("Request Method: PUT");
        System.out.println("Endpoint: /api/departments/" + id);
        System.out.println("Action: Updating existing department in MongoDB...");
        System.out.println("Target ID: " + id);
        System.out.println("New Name: " + department.getName());
        System.out.println("=========================================");
        
        department.setId(id); // Ensures we update the existing record, not make a new one
        return repository.save(department);
    }

    // 4. DELETE
    @DeleteMapping("/{id}")
    public void deleteDepartment(@PathVariable String id) {
        System.out.println("=========================================");
        System.out.println("Request Method: DELETE");
        System.out.println("Endpoint: /api/departments/" + id);
        System.out.println("Action: Removing department from database...");
        System.out.println("Target ID: " + id);
        System.out.println("=========================================");
        
        repository.deleteById(id);
    }

    // 5. CUSTOM SEARCH (GET)
    @GetMapping("/search")
    public List<Department> searchDepartments(@RequestParam String keyword) {
        System.out.println("=========================================");
        System.out.println("Request Method: GET (Custom Query)");
        System.out.println("Endpoint: /api/departments/search?keyword=" + keyword);
        System.out.println("Action: Executing NoSQL Regex Search...");
        System.out.println("Search Keyword: [" + keyword + "]");
        System.out.println("=========================================");
        
        return repository.searchByName(keyword);
    }
}