package com.example.demo.controller;

import com.example.demo.model.Staff;
import com.example.demo.repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/staff")
public class StaffController {

    @Autowired
    private StaffRepository repository;

    @PostMapping
    public Staff createStaff(@RequestBody Staff staff) {
        System.out.println("=========================================");
        System.out.println("Request Method: POST");
        System.out.println("Endpoint: /api/staff");
        System.out.println("Action: Saving new staff member to MongoDB...");
        System.out.println("=========================================");
        return repository.save(staff);
    }

    @GetMapping
    public List<Staff> getAllStaff() {
        System.out.println("=========================================");
        System.out.println("Request Method: GET");
        System.out.println("Endpoint: /api/staff");
        System.out.println("Action: Fetching all staff members from database...");
        System.out.println("=========================================");
        return repository.findAll();
    }

    @PutMapping("/{id}")
    public Staff updateStaff(@PathVariable String id, @RequestBody Staff staff) {
        System.out.println("=========================================");
        System.out.println("Request Method: PUT");
        System.out.println("Endpoint: /api/staff/" + id);
        System.out.println("Action: Updating staff member in MongoDB...");
        System.out.println("=========================================");
        staff.setId(id);
        return repository.save(staff);
    }

    @DeleteMapping("/{id}")
    public void deleteStaff(@PathVariable String id) {
        System.out.println("=========================================");
        System.out.println("Request Method: DELETE");
        System.out.println("Endpoint: /api/staff/" + id);
        System.out.println("Action: Removing staff member from database...");
        System.out.println("=========================================");
        repository.deleteById(id);
    }
}