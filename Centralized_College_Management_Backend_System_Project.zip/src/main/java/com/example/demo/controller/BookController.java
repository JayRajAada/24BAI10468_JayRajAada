package com.example.demo.controller;

import com.example.demo.model.Book;
import com.example.demo.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/books")
public class BookController {

    @Autowired
    private BookRepository repository;

    @PostMapping
    public Book createBook(@RequestBody Book book) {
        System.out.println("=========================================");
        System.out.println("Request Method: POST");
        System.out.println("Endpoint: /api/books");
        System.out.println("Action: Saving new book to MongoDB...");
        System.out.println("=========================================");
        return repository.save(book);
    }

    @GetMapping
    public List<Book> getAllBooks() {
        System.out.println("=========================================");
        System.out.println("Request Method: GET");
        System.out.println("Endpoint: /api/books");
        System.out.println("Action: Fetching all books from database...");
        System.out.println("=========================================");
        return repository.findAll();
    }

    // BORROW ACTION: Pushes a student ID into the array
    @PutMapping("/{bookId}/borrow/{studentId}")
    public Book borrowBook(@PathVariable String bookId, @PathVariable String studentId) {
        System.out.println("=========================================");
        System.out.println("Request Method: PUT");
        System.out.println("Endpoint: /api/books/" + bookId + "/borrow/" + studentId);
        System.out.println("Action: Processing book borrow request...");
        System.out.println("Target Book ID: " + bookId);
        System.out.println("Borrowing Student ID: " + studentId);
        System.out.println("=========================================");
        
        Optional<Book> bookOpt = repository.findById(bookId);
        if (bookOpt.isPresent()) {
            Book book = bookOpt.get();
            if (!book.getCurrentBorrowers().contains(studentId)) {
                book.getCurrentBorrowers().add(studentId);
                return repository.save(book);
            }
            return book;
        }
        throw new RuntimeException("Book not found");
    }

    // RETURN ACTION: Removes a student ID from the array
    @DeleteMapping("/{bookId}/borrow/{studentId}")
    public Book returnBook(@PathVariable String bookId, @PathVariable String studentId) {
        System.out.println("=========================================");
        System.out.println("Request Method: DELETE");
        System.out.println("Endpoint: /api/books/" + bookId + "/borrow/" + studentId);
        System.out.println("Action: Processing book return request...");
        System.out.println("Target Book ID: " + bookId);
        System.out.println("Returning Student ID: " + studentId);
        System.out.println("=========================================");
        
        Optional<Book> bookOpt = repository.findById(bookId);
        if (bookOpt.isPresent()) {
            Book book = bookOpt.get();
            book.getCurrentBorrowers().remove(studentId);
            return repository.save(book);
        }
        throw new RuntimeException("Book not found");
    }
}