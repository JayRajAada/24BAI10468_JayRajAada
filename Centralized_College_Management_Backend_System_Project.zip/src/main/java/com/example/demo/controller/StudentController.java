package com.example.demo.controller;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    @Autowired
    private StudentRepository repository;

    @PostMapping
    public Student createStudent(@RequestBody Student student) {
        System.out.println("=========================================");
        System.out.println("Request Method: POST");
        System.out.println("Endpoint: /api/students");
        System.out.println("Action: Saving new student & academic profile to MongoDB...");
        System.out.println("Student Name: " + student.getName());
        System.out.println("=========================================");
        return repository.save(student);
    }

    @GetMapping
    public List<Student> getAllStudents() {
        System.out.println("=========================================");
        System.out.println("Request Method: GET");
        System.out.println("Endpoint: /api/students");
        System.out.println("Action: Fetching all students from database...");
        System.out.println("=========================================");
        return repository.findAll();
    }

    @PutMapping("/{id}")
    public Student updateStudent(@PathVariable String id, @RequestBody Student student) {
        System.out.println("=========================================");
        System.out.println("Request Method: PUT");
        System.out.println("Endpoint: /api/students/" + id);
        System.out.println("Action: Updating existing student in MongoDB...");
        System.out.println("=========================================");
        student.setId(id);
        return repository.save(student);
    }

    @DeleteMapping("/{id}")
    public void deleteStudent(@PathVariable String id) {
        System.out.println("=========================================");
        System.out.println("Request Method: DELETE");
        System.out.println("Endpoint: /api/students/" + id);
        System.out.println("Action: Removing student from database...");
        System.out.println("=========================================");
        repository.deleteById(id);
    }
}