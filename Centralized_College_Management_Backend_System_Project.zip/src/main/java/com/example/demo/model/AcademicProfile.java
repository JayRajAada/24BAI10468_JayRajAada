package com.example.demo.model;

public class AcademicProfile {
    private double cgpa;
    private int currentSemester;

    // Getters and Setters
    public double getCgpa() { return cgpa; }
    public void setCgpa(double cgpa) { this.cgpa = cgpa; }
    public int getCurrentSemester() { return currentSemester; }
    public void setCurrentSemester(int currentSemester) { this.currentSemester = currentSemester; }
}