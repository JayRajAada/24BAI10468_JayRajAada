package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.ArrayList;
import java.util.List;

@Document(collection = "books")
public class Book {
    @Id
    private String id;
    private String title;
    private String author;
    private List<String> currentBorrowers = new ArrayList<>(); // Array of Student IDs

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    public List<String> getCurrentBorrowers() { return currentBorrowers; }
    public void setCurrentBorrowers(List<String> currentBorrowers) { this.currentBorrowers = currentBorrowers; }
}